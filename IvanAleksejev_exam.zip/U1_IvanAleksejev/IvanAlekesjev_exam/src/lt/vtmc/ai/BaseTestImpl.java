package lt.vtmc.ai;

import lt.vtmc.exam.TransportManager;
import lt.vtmc.exam.test.BaseTest;

public class BaseTestImpl extends BaseTest 	 {

	@Override
	protected TransportManager createTransportManager() {
		TransportManager tm = new TransportManagerImpl();
		return null;
	}

	
}
