package lt.vtmc.ai;

import lt.vtmc.exam.Passenger;
import lt.vtmc.exam.PassengerPredicate;

public class PassengerPred implements PassengerPredicate{

	@Override
	public boolean test(Passenger id) {
		// TODO Auto-generated method stub
		
		
		return false;
	}

}
