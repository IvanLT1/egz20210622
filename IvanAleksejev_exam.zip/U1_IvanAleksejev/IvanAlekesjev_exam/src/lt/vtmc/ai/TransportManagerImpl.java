package lt.vtmc.ai;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import lt.vtmc.exam.Bus;
import lt.vtmc.exam.Passenger;
import lt.vtmc.exam.PassengerPredicate;
import lt.vtmc.exam.SeatIsOccupiedException;
import lt.vtmc.exam.TransportManager;

public class TransportManagerImpl implements TransportManager{
	private ArrayList<Bus> buses;

	public TransportManagerImpl(ArrayList<Bus> buses) {
		super();
		this.buses = buses;
	}

	public TransportManagerImpl() {
		super();
	}

	public ArrayList<Bus> getBuses() {
		return buses;
	}

	public void setBuses(ArrayList<Bus> buses) {
		this.buses = buses;
	}

	@Override
	public Bus createBus(String id, int seats) {
		int a =0;
		Bus bus = null;
		//Bus b = new Bus(id,seats);
		//if(this.buses.stream().noneMatch(u->u.getId().equals(id))) {this.buses.add(b);return b;}
		//else return null;
		for (Bus b: this.buses) {
			if (b.getId().equals(id)) {
				a = 1;
			} }
		if (a==0) {bus= new Bus(id,seats);}
		return bus;
	}

	@Override
	public Passenger createPassenger(String name, String surname, int age) {
		Passenger p = new Passenger(name,surname,age);
		return p;
	}

	@Override
	public List<Passenger> findPassengersBy(String busId, PassengerPredicate arg1) {
		Bus b = getBusById(busId);
		
		return null;
	}

	@Override
	public double getAveragePassengerAge(String busId) {
		double count = 0.0;
		double sum = 0.0;
		for (Bus b: this.buses) {
			if (b.getId().equals(busId)) {
				for (Passenger p: b.getPassengers()) {
					count ++;
					sum += p.getAge();					
				}
			}			
		}	
		return sum/count;
	}

	@Override
	public Bus getBusById(String id) {
		return this.buses.stream().filter(u->u.getId().equals(id)).findFirst().orElse(null) ;		
	}

	@Override
	public List<Bus> getCreatedBuses() {		
		return this.buses;
	}

	@Override
	public Passenger getOldestPassenger(String busId) {
		int maxAge=0;
		Passenger pmax=null;
		Bus b = getBusById(busId);
		if (b != null) {
		for (Passenger p: b.getPassengers()) {
			if(p.getAge()>maxAge) {
				maxAge=p.getAge();
				pmax= p;
			}								
		}		
		}		
		return pmax;
	}

	@Override
	public Collection<Passenger> getOrderedPassengers(String busId) {
		Bus b = getBusById(busId);
		
		List<Passenger> sorted = b.getPassengers();
		if (sorted.size() > 0) {
		Collections.sort(sorted, new Comparator<Passenger>() {
			public int compare (Passenger p1,Passenger p2) {
				
				if(p1.getSurname().compareTo(p2.getSurname())>0) { return 1;}
				else if(p1.getSurname().compareTo(p2.getSurname())<0) { return -1;}
				else if (p1.getName().compareTo(p2.getName())>0 ) { return 1;}
				else if (p1.getName().compareTo(p2.getName()) < 0) { return -1;}
				return 0;
				
			}			
		}				
				);}
		
		return sorted;
	}

	@Override
	public List<Passenger> getPassengers(String busId) {
		Bus b = getBusById(busId);
		List<Passenger> p = b.getPassengers();
		return p;
	}

	@Override
	public void registerPassenger(Bus b, int seatNr, Passenger p) throws SeatIsOccupiedException {

		if (p.getName() == null || p.getSurname() == null
                || p.getAge() == 0)
        {  
            throw new IllegalArgumentException(p.toString());}
        else {
      if (!b.isSeatOccupied(seatNr)==false) {
    	  	p.setSeatNo(seatNr);
            b.registerPassenger(seatNr, p);
        }
      else {
          throw new SeatIsOccupiedException();
      }
        
        }		
	}
}
